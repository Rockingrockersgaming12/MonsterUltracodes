const mongoose = require("mongoose");
const config = require("./config");

mongoose.connect("mongodb+srv://Monster12:rockingrockers12345@cluster0.r4jst.mongodb.net/myFirstDatabase?retryWrites=true&w=majority", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
mongoose.connection.on("connected", () => {
  console.log("[✅ DataBase] Connected!");
});
module.exports = mongoose;
